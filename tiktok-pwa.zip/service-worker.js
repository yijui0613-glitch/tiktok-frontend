self.addEventListener('install', function(e){
  e.waitUntil(
    caches.open('tiktok-preview-v1').then(function(cache){
      return cache.addAll([
        '/index.html',
        '/icon.png'
      ]);
    })
  );
  self.skipWaiting();
});

self.addEventListener('fetch', function(e){
  e.respondWith(
    caches.match(e.request).then(function(r){
      return r || fetch(e.request);
    })
  );
});
